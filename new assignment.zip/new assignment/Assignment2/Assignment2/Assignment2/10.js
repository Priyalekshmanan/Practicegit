const ordalph = (input) => {
    return input.split('').sort().join('');
};

const inputString = 'webmaster';
console.log(ordalph(inputString));  
