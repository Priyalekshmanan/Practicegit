const multiply = (a, b) => a * b;
const divide = (a, b) => a / b;

console.log(multiply(5, 3));
console.log(divide(10, 2));
