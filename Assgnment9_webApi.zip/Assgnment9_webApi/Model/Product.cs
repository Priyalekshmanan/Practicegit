﻿namespace Assgnment9_webApi.Model
{
    public class Product
    {
        public int  Prod_Id {  get; set; }
        public string ProdName { get; set; }
        public string Category { get; set; }
        public double Price {  get; set;}
        public int Stock {  get; set;}
    }
}
