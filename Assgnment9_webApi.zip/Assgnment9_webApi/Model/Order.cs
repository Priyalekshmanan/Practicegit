﻿namespace Assgnment9_webApi.Model
{
    public class Order
    {
        public int Id { get; set; }
        public int Prod_Id {  get; set; }
        public DateTime Orderdate { get; set; }
        public int Quantity { get; set;}

        public decimal Amount { get; set;}
    }
}
