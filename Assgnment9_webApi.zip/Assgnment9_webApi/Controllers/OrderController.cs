﻿using Assgnment9_webApi.Model;
using Assgnment9_webApi.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Assgnment9_webApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        public readonly IOrderrepository orderrepository;
        public OrderController(IOrderrepository orderrepository)
        {
            this.orderrepository = orderrepository;
        }
        [HttpPost("AddProduct")]
        public IActionResult Add(int Prod_Id)
        {



            try
            {
                Order order = new Order
                {
                    Prod_Id = Prod_Id,
                };
                orderrepository.Add(order);
                return StatusCode(200, order);
            }
            catch (Exception ex)
            {

                return StatusCode(501, ex);
            }
        
        }
        [HttpGet("GetAllCmpanies")]
        public IActionResult GetAll()
        {
            try
            {
                List<Order> order = orderrepository.GetAll();
                return StatusCode(200, order);
            }
            catch (Exception ex)
            {

                return StatusCode(501, ex);
            }
        }
        [HttpDelete("Delete/{id}")]
        public IActionResult DeleteStudent(int id)
        {
            try
            {
                orderrepository.DeleteOrder(id);
                return StatusCode(200, "Order deleted");
            }
            catch (Exception ex)
            {

                return StatusCode(501, ex);
            }
        }
    }
}
