﻿using Assgnment9_webApi.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Assgnment9_webApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private Productservices productservice;
        public ProductController(Productservices productservice)
        {
            this.productservice = productservice;
        }
        [HttpPost]
    }
}
