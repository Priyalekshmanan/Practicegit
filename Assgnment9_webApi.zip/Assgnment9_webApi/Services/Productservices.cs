﻿using Assgnment9_webApi.Model;

namespace Assgnment9_webApi.Services
{
    public class Productservices
    {
        private List<Product>products = new List<Product>();

        public string ProdName { get; private set; }

        public void AddProduct(Product product)
        {
            product.Prod_Id = products.Count + 1;
            products.Add(product);
        }
        public void ModifyProduct(Product product)
        {
            var existingProduct = products.FirstOrDefault(p=>p.Prod_Id==product.Prod_Id);
            if(existingProduct != null)
            {
                existingProduct.ProdName = product.ProdName;
                existingProduct.Category = product.Category;
                existingProduct.Price = product.Price;  
                existingProduct.Stock = product.Stock;
            }


        }
        public void DeleteProduct(int id) {

            var producttodelete=products.FirstOrDefault(p=>p.Prod_Id == id);
            if (producttodelete !=null)
            {
                products.Remove(producttodelete);
            }
        }
        public List<Product> SearchProducts(string ProdName, string Category) 
        { 
            return products.Where(p=>p.Category.Contains(Category)).ToList();   
        }
        public List<Product> SearchProductsByCategory(string Category)
        {
            return products.Where(p => p.Category.Contains(Category)).ToList();
        }
    }

}
