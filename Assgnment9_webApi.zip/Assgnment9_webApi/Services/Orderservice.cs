﻿using Assgnment9_webApi.Model;

namespace Assgnment9_webApi.Services
{
    public class Orderservice
    {
        private List<Order> orders = new List<Order>();
        public void PlaceOrder(Order order)
         {
        order.Id = orders.Count + 1;
        order.Orderdate = DateTime.Now;
        orders.Add(order);
    }

    public List<Order> ViewOrderedItems()
    {
        return orders;
    }

    public void DeleteProductFromOrder(int productId)
    {
        orders.RemoveAll(o => o.Prod_Id == productId);
    }
}
}
